<?php

/**
 * vCardMaker Backend
 *
 * Creates an electronic business card based on the vCard standard from provided information.
 *
 * This file is released under a Creative Commons Attribution-Share Alike 2.0 UK: England & Wales Licence.
 * More information is available at http://creativecommons.org/licenses/by-sa/2.0/uk/.
 *
 * @author Ruben Arakelyan
 */

class vCardMaker {

  // FUNCTION: Returns or echos the vCardMaker version number
  // - Arguments: $format -> false = version number, true = version string
  // vCardMaker uses the Linux kernel versioning system documented at http://en.wikipedia.org/wiki/Linux_kernel
  public static function Version($format = false) {
    // Set up the version variables
    $vCardMaker_Name    = 'vCardMaker';
    $vCardMaker_Version = '0.7.1';
    $vCardMaker_String  = $vCardMaker_Name.' '.$vCardMaker_Version;
    // Return version number or string
    if ($format) {
      return $vCardMaker_String;
    } else {
      return $vCardMaker_Version;
    }
  }

  // FUNCTION: Make the vCard
  // - Arguments: $Request -> contents of $_REQUEST superglobal
  public static function Make($Request) {
    // Validate the card
    if (vCardMaker::Validate($Request)) {
      vCardMaker::Deliver($Request, 1);
    }
  }

  // FUNCTION: Validate the vCard
  // - Arguments: $Request -> contents of $_REQUEST superglobal
  public static function Validate($Request) {

    // Get the appropriate language file
    require 'vcard.class.lang.php';

    // Set up the validation variable
    $vCardValidate = '';

    // Make sure vCard version is present - now defaults to 2.1
    if (!isset($Request['Version-vCard'])) {
      //$vCardValidate .= $vCardLang['NoVersion']."\n";
      $Request['Version-vCard'] = '2.1';
    }

    // Make sure vCard name and source are present (if appropriate; only 3.0)
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && ((trim($Request['Name']) != '' && trim($Request['Source']) == '') || (trim($Request['Name']) == '' && trim($Request['Source']) != ''))) {
      $vCardValidate .= $vCardLang['NoNameSource']."\n";
    }

    // Make sure formatted name is present
    if ($Request['Formatted_Name'] == '') {
      $vCardValidate .= $vCardLang['NoFormattedName']."\n";
    }

    // Make sure forename is present
    if ($Request['Name_Forename'] == '') {
      $vCardValidate .= $vCardLang['NoForename']."\n";
    }

    // Make sure surname is present
    if ($Request['Name_Surname'] == '') {
      $vCardValidate .= $vCardLang['NoSurname']."\n";
    }

    // Make sure quoted-printable photo isn't used for a 3.0 vCard
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && $Request['Photo_Type'] == 'QUOTED-PRINTABLE') {
      $vCardValidate .= $vCardLang['NoPhotoQP']."\n";
    }

    // Make sure the photo URL is present (if appropriate)
    if ($Request['Photo_Type'] == 'URL' && $Request['Photo_Source_URL'] == '') {
      $vCardValidate .= $vCardLang['NoPhotoURL']."\n";
    }

    // Make sure the photo source is present (if appropriate)
    if (($Request['Photo_Type'] == 'BASE64' || $Request['Photo_Type'] == 'QUOTED-PRINTABLE') && $Request['Photo_Source_Quoted'] == '') {
      $vCardValidate .= $vCardLang['NoPhotoSource']."\n";
    }

    // Make sure that the birth date is in the correct format
    if (isset($Request['Birthdate']) && $Request['Birthdate'] != '' && preg_match('/^\d{4}-\d{2}-\d{2}/', $Request['Birthdate']) == 0) {
      $vCardValidate .= $vCardLang['NoBirthdate']."\n";
    }

    // Make sure that the birth time is present (if appropriate)
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && isset($Request['Birthtime']) && $Request['Birthtime'] != '' && $Request['Birthdate'] == '') {
      $vCardValidate .= $vCardLang['NoBirthdatetime']."\n";
    }

    // Make sure that the birth time is in the correct format
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && isset($Request['Birthtime']) && $Request['Birthtime'] != '' && preg_match('/^\d{2}:\d{2}:\d{2}/', $Request['Birthtime']) == 0) {
      $vCardValidate .= $vCardLang['NoBirthtime']."\n";
    }

    // Make sure that the birth timezone is present (if appropriate)
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && isset($Request['Birthtimezone']) && $Request['Birthtimezone'] != '' && $Request['Birthtime'] == '') {
      $vCardValidate .= $vCardLang['NoBirthtimezone']."\n";
    }

    // Make sure the address street is present (if appropriate)
    if (isset($Request['DeliveryAddress_Type']) && $Request['DeliveryAddress_Type'] != '' && $Request['DeliveryAddress_Street'] == '') {
      $vCardValidate .= $vCardLang['NoDeliveryStreet']."\n";
    }

    // Make sure the address locality is present (if appropriate)
    if (isset($Request['DeliveryAddress_Type']) && $Request['DeliveryAddress_Type'] != '' && $Request['DeliveryAddress_Locality'] == '') {
      $vCardValidate .= $vCardLang['NoDeliveryLocality']."\n";
    }

    // Make sure the address postal code is present (if appropriate)
    if (isset($Request['DeliveryAddress_Type']) && $Request['DeliveryAddress_Type'] != '' && $Request['DeliveryAddress_PostalCode'] == '') {
      $vCardValidate .= $vCardLang['NoDeliveryPostCode']."\n";
    }

    // Make sure the address country is present (if appropriate)
    if (isset($Request['DeliveryAddress_Type']) && $Request['DeliveryAddress_Type'] != '' && $Request['DeliveryAddress_Country'] == '') {
      $vCardValidate .= $vCardLang['NoDeliveryCountry']."\n";
    }

    // Make sure the delivery label street is present (if appropriate)
    if (isset($Request['DeliveryLabel_Type']) && $Request['DeliveryLabel_Type'] != '' && $Request['DeliveryLabel_Street'] == '') {
      $vCardValidate .= $vCardLang['NoLabelStreet']."\n";
    }

    // Make sure the delivery label locality is present (if appropriate)
    if (isset($Request['DeliveryLabel_Type']) && $Request['DeliveryLabel_Type'] != '' && $Request['DeliveryLabel_Locality'] == '') {
      $vCardValidate .= $vCardLang['NoLabelLocality']."\n";
    }

    // Make sure the delivery label postal code is present (if appropriate)
    if (isset($Request['DeliveryLabel_Type']) && $Request['DeliveryLabel_Type'] != '' && $Request['DeliveryLabel_PostalCode'] == '') {
      $vCardValidate .= $vCardLang['NoLabelPostCode']."\n";
    }

    // Make sure the delivery label country is present (if appropriate)
    if (isset($Request['DeliveryLabel_Type']) && $Request['DeliveryLabel_Type'] != '' && $Request['DeliveryLabel_Country'] == '') {
      $vCardValidate .= $vCardLang['NoLabelCountry']."\n";
    }

    // Make sure the telephone number is present (if appropriate)
    if ($Request['TelephoneNumber_Type'] != '' && $Request['TelephoneNumber_Number'] == '') {
      $vCardValidate .= $vCardLang['NoTelNumber']."\n";
    }

    // Make sure the telephone number (2) is present (if appropriate)
    if ($Request['TelephoneNumber_Type_2'] != '' && $Request['TelephoneNumber_Number_2'] == '') {
      $vCardValidate .= $vCardLang['NoTelNumber']."\n";
    }

    // Make sure the email address is present
    if ($Request['EmailAddress_Type'] == '' || $Request['EmailAddress_Address'] == '') {
      $vCardValidate .= $vCardLang['NoEmailAddress']."\n";
    }

    // Make sure the email address (2) is present (if appropriate)
    if ($Request['EmailAddress_Type_2'] != '' && $Request['EmailAddress_Address_2'] == '') {
      $vCardValidate .= $vCardLang['NoEmailAddress']."\n";
    }

    // Make sure the whole geographical location is present (if appropriate)
    if (trim($Request['GeographicalProperties_Position_Latitude_Whole']) != '' && trim($Request['GeographicalProperties_Position_Latitude_Fraction']) == '') {
      $vCardValidate .= $vCardLang['NoGeoLoc']."\n";
    }

    // Make sure the whole geographical location is present (if appropriate)
    if (trim($Request['GeographicalProperties_Position_Longitude_Whole']) != '' && trim($Request['GeographicalProperties_Position_Longitude_Fraction']) == '') {
      $vCardValidate .= $vCardLang['NoGeoLoc']."\n";
    }

    // Make sure the whole geographical location is present (if appropriate)
    if (trim($Request['GeographicalProperties_Position_Latitude_Whole']) != '' && trim($Request['GeographicalProperties_Position_Longitude_Whole']) == '') {
      $vCardValidate .= $vCardLang['NoGeoLoc']."\n";
    }

    // Make sure quoted-printable logo isn't used for a 3.0 vCard
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && $Request['Logo_Type'] == 'QUOTED-PRINTABLE') {
      $vCardValidate .= $vCardLang['NoLogoQP']."\n";
    }

    // Make sure the logo URL is present (if appropriate)
    if ($Request['Logo_Type'] == 'URL' && $Request['Logo_Source_URL'] == '') {
      $vCardValidate .= $vCardLang['NoLogoURL']."\n";
    }

    // Make sure the logo source is present (if appropriate)
    if (($Request['Logo_Type'] == 'BASE64' || $Request['Logo_Type'] == 'QUOTED-PRINTABLE') && $Request['Logo_Source_Quoted'] == '') {
      $vCardValidate .= $vCardLang['NoLogoSource']."\n";
    }

    // Make sure the agent vCard is present (if appropriate)
    if ($Request['Agent_Type'] == 'vCard' && $Request['Agent'] == '') {
      $vCardValidate .= $vCardLang['NoAgentvCard']."\n";
    }

    // Make sure the agent URL is present (if appropriate)
    if ($Request['Agent_Type'] == 'URL' && $Request['Agent_URL'] == '') {
      $vCardValidate .= $vCardLang['NoAgentURL']."\n";
    }

    // Make sure agent URL isn't used for a 2.1 vCard
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '2.1' && $Request['Agent_Type'] == 'URL') {
      $vCardValidate .= $vCardLang['NoAgentURLType']."\n";
    }

    // Make sure binary key type isn't used for a 2.1 vCard
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '2.1' && $Request['Key_Type'] == 'B') {
      $vCardValidate .= $vCardLang['NoKeyBinary']."\n";
    }

    // Make sure phonetic sound type isn't used for a 3.0 vCard
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && $Request['Sound_Type'] == 'Phonetic') {
      $vCardValidate .= $vCardLang['NoSoundPhonetic']."\n";
    }

    // Make sure the sound phonetic representation is present (if appropriate)
    if ($Request['Sound_Type'] == 'Phonetic' && $Request['Sound_Source_Phonetic'] == '') {
      $vCardValidate .= $vCardLang['NoSoundPhoneticR']."\n";
    }

    // Make sure the sound URL is present (if appropriate)
    if ($Request['Sound_Type'] == 'URL' && $Request['Sound_Source_URL'] == '') {
      $vCardValidate .= $vCardLang['NoSoundURL']."\n";
    }

    // Make sure the sound source is present (if appropriate)
    if ($Request['Sound_Type'] == 'BASE64' && $Request['Sound_Source_Quoted'] == '') {
      $vCardValidate .= $vCardLang['NoSoundSource']."\n";
    }

    // Make sure PGP and X.509 key types aren't used for a 3.0 vCard
    if (isset($Request['Version-vCard']) && $Request['Version-vCard'] == '3.0' && ($Request['Key_Type'] == 'PGP' || $Request['Key_Type'] == 'X509')) {
      $vCardValidate .= $vCardLang['NoKeyPGPX509']."\n";
    }

    // Make sure the key source is present (if appropriate)
    if (($Request['Key_Type'] == 'PGP' || $Request['Key_Type'] == 'X509' || $Request['Key_Type'] == 'B') && $Request['Key_Quoted'] == '') {
      $vCardValidate .= $vCardLang['NoKeySource']."\n";
    }

    // Check to see if any errors should be returned
    if (isset($vCardValidate) && $vCardValidate != '') {
      // Errors
      $vCardValidateH = explode("\n", $vCardValidate);
      $vCardValidate = '<pre id="result"><strong>'.$vCardLang['VErrorsFound'].'</strong><ul>';
      for ($x = 0; $x < (count($vCardValidateH) - 1); $x++) {
        $vCardValidate .= '<li>'.$vCardValidateH[$x].'</li>';
      }
      $vCardValidate .= '</ul></pre>'."\n";
      echo $vCardValidate;
      return false;
    } else {
      // No errors
      return true;
    }

  }

  // FUNCTION: Deliver the vCard
  // - Arguments: $Request -> contents of $_REQUEST superglobal; $Return -> 0 = return vCard, 1 = echo HTML, 2 = echo vCard
  public static function Deliver($Request, $Return) {

    // Get the appropriate language file
    require 'vcard.class.lang.php';

    // Escape characters
    if (!function_exists('escape')) {
      function escape(&$item, $key) {
        $item = str_replace(':', '\:', $item);
        $item = str_replace(';', '\;', $item);
        $item = str_replace(',', '\,', $item);
      }
    }
    array_walk($Request, 'escape');

    // Begin vCard Delimiter
    $vCard = 'BEGIN:VCARD'."\n";

    // vCard Version
    switch ($Request['Version-vCard']) {
      case '3.0':
        $vCard .= 'VERSION:3.0'."\n";
        break;
      case '2.1':
      default:
        $vCard .= 'VERSION:2.1'."\n";
    }

    // vCard Profile (only 3.0)
    if ($Request['Version-vCard'] == '3.0') {
      $vCard .= 'PROFILE:VCARD'."\n";
    }

    // Name and Source (only 3.0)
    if ($Request['Version-vCard'] == '3.0' && trim($Request['Name']) != '' && trim($Request['Source']) != '') {
      $vCard .= 'NAME:'.$Request['Name']."\n".'SOURCE:'.$Request['Source']."\n";
    }

    // Formatted Name
    $vCard .= 'FN:'.trim($Request['Formatted_Name'])."\n";

    // Name
    $vCard .= 'N:'.trim($Request['Name_Surname']).';'.trim($Request['Name_Forename']).';'.trim($Request['Name_AdditionalNames']).';'.trim($Request['Name_Prefix']).';'.trim($Request['Name_Suffix'])."\n";

    // Sort (only 3.0)
    if ($Request['Version-vCard'] == '3.0' && $Request['Sort'] != '') {
      $vCard .= 'SORT-STRING:'.$Request['Sort']."\n";
    }

    // Nickname (only 3.0)
    if ($Request['Version-vCard'] == '3.0' && $Request['Nickname'] != '') {
      $vCard .= 'NICKNAME:'.$Request['Nickname']."\n";
    }

    // Photo
    if ($Request['Photo_Type'] != 'None') {
      $vCard .= 'PHOTO;';
      switch ($Request['Photo_Type']) {
        case 'BASE64':
          $vCard .= 'ENCODING=';
          if ($Request['Version-vCard'] == '2.1') {
            $vCard .= 'BASE64:';
          } else {
            $vCard .= 'b:';
          }
          $vCard .= ';TYPE='.$Request['Photo_Format'].':'.trim($Request['Photo_Source_Quoted'])."\n";
          break;
        case 'QUOTED-PRINTABLE':
          $vCard .= 'ENCODING:QUOTED-PRINTABLE;TYPE='.$Request['Photo_Format'].':'.trim($Request['Photo_Source_Quoted'])."\n";
          break;
        case 'URL':
        default:
          $vCard .= 'VALUE=';
          if ($Request['Version-vCard'] == '2.1') {
            $vCard .= 'URL:';
          } else {
            $vCard .= 'uri:';
          }
          $vCard .= trim($Request['Photo_Source_URL'])."\n";
      }
    }

    // Birthdate and birthtime
    if ($Request['Birthdate'] != '') {
      $vCard .= 'BDAY:'.trim($Request['Birthdate']);
      if ($Request['Version-vCard'] == '3.0' && $Request['Birthtime'] != '') {
        $vCard .= 'T'.trim($Request['Birthtime']);
        if ($Request['Birthtimezone'] != '') {
          $vCard .= trim($Request['Birthtimezone'])."\n";
        } else {
          $vCard .= 'Z'."\n";
        }
      } else {
        $vCard .= "\n";
      }
    }

    // Delivery Address
    if (isset($Request['DeliveryAddress_Type']) && $Request['DeliveryAddress_Type'] != '') {
      $vCard .= 'ADR';
      foreach ($Request['DeliveryAddress_Type'] as $type) {
        if ($Request['Version-vCard'] == '2.1') {
          $vCard .= ';'.$type;
        } else {
          $vCard .= ';TYPE='.$type;
        }
      }
      $vCard .= ':'.trim($Request['DeliveryAddress_PostOfficeAddress']).';'.trim($Request['DeliveryAddress_ExtendedAddress']).';'.trim($Request['DeliveryAddress_Street']).';'.trim($Request['DeliveryAddress_Locality']).';'.trim($Request['DeliveryAddress_Region']).';'.trim($Request['DeliveryAddress_PostalCode']).';'.$Request['DeliveryAddress_Country']."\n";
    }

    // Delivery Label
    if ($Request['Version-vCard'] == '2.1') {
      $separator = '=0D=0A=';
    } else {
      $separator = '\n';
    }
    if (isset($Request['DeliveryLabel_Type']) && $Request['DeliveryLabel_Type'] != '') {
      $vCard .= 'LABEL';
      foreach ($Request['DeliveryLabel_Type'] as $type) {
        if ($Request['Version-vCard'] == '2.1') {
          $vCard .= ';'.$type;
        } else {
          $vCard .= ';TYPE='.$type;
        }
      }
      if ($Request['Version-vCard'] == '2.1') {
        $vCard .= ';ENCODING=QUOTED-PRINTABLE';
      }
      $vCard .= ':'.trim($Request['DeliveryLabel_PostOfficeAddress']).$separator.trim($Request['DeliveryLabel_ExtendedAddress']).$separator.trim($Request['DeliveryLabel_Street']).$separator.trim($Request['DeliveryLabel_Locality']).$separator.trim($Request['DeliveryLabel_Region']).$separator.trim($Request['DeliveryLabel_PostalCode']).$separator.$Request['DeliveryLabel_Country']."\n";
    }

    // Telephone Number (1)
    if ($Request['TelephoneNumber_Type'] != '') {
      $vCard .= 'TEL;';
      if ($Request['Version-vCard'] == '2.1') {
        $vCard .= 'PREF';
      } else {
        $vCard .= 'TYPE=PREF';
      }
      if ($Request['TelephoneNumber_Type_Msg'] == 'MSG') {
        if ($Request['Version-vCard'] == '2.1') {
          $vCard .= ';MSG';
        } else {
          $vCard .= ';TYPE=MSG';
        }
      }
      $vCard .= ';';
      if ($Request['Version-vCard'] == '3.0') {
        $vCard .= 'TYPE=';
      }
      $vCard .= $Request['TelephoneNumber_Type'].':'.trim($Request['TelephoneNumber_Number'])."\n";
    }

    // Telephone Number (2)
    if ($Request['TelephoneNumber_Type_2'] != '') {
      $vCard .= 'TEL';
      if ($Request['TelephoneNumber_Type_Msg_2'] == 'MSG') {
        if ($Request['Version-vCard'] == '2.1') {
          $vCard .= ';MSG';
        } else {
          $vCard .= ';TYPE=MSG';
        }
      }
      $vCard .= ';';
      if ($Request['Version-vCard'] == '3.0') {
        $vCard .= 'TYPE=';
      }
      $vCard .= $Request['TelephoneNumber_Type_2'].':'.trim($Request['TelephoneNumber_Number_2'])."\n";
    }

    // Email Address (1)
    if ($Request['EmailAddress_Type'] != '') {
      $vCard .= 'EMAIL;';
      if ($Request['Version-vCard'] == '3.0') {
        $vCard .= 'TYPE=';
      }
      $vCard .= $Request['EmailAddress_Type'];
      if ($Request['Version-vCard'] == '3.0') {
        $vCard .= ';TYPE=PREF:';
      } else {
        $vCard .= ':';
      }
      $vCard .= trim($Request['EmailAddress_Address'])."\n";
    }

    // Email Address (2)
    if ($Request['EmailAddress_Type_2'] != '') {
      $vCard .= 'EMAIL;';
      if ($Request['Version-vCard'] == '3.0') {
        $vCard .= 'TYPE=';
      }
      $vCard .= $Request['EmailAddress_Type_2'].':'.trim($Request['EmailAddress_Address_2'])."\n";
    }

    // Mailer
    if (trim($Request['Mailer_Name']) != '') {
      $vCard .= 'MAILER:'.trim($Request['Mailer_Name'])."\n";
    }

    // Timezone
    if ($Request['GeographicalProperties_Timezone'] != '') {
      $vCard .= 'TZ:'.$Request['GeographicalProperties_Timezone']."\n";
    }

    // Geographic Position
    if (trim($Request['GeographicalProperties_Position_Latitude_Whole']) != '') {
      $vCard .= 'GEO:'.$Request['GeographicalProperties_Position_Latitude_Sign'].trim($Request['GeographicalProperties_Position_Latitude_Whole']).'.'.trim($Request['GeographicalProperties_Position_Latitude_Fraction']).','.$Request['GeographicalProperties_Position_Longitude_Sign'].trim($Request['GeographicalProperties_Position_Longitude_Whole']).'.'.trim($Request['GeographicalProperties_Position_Longitude_Fraction'])."\n";
    }

    // Title
    if (trim($Request['OrganisationalProperties_JobTitle']) != '') {
      $vCard .= 'TITLE:'.trim($Request['OrganisationalProperties_JobTitle'])."\n";
    }

    // Role
    if (trim($Request['OrganisationalProperties_Role']) != '') {
      $vCard .= 'ROLE:'.trim($Request['OrganisationalProperties_Role'])."\n";
    }

    // Logo
    if ($Request['Logo_Type'] != 'None') {
      $vCard .= 'LOGO;';
      switch ($Request['Logo_Type']) {
        case 'BASE64':
          $vCard .= 'ENCODING=';
          if ($Request['Version-vCard'] == '2.1') {
            $vCard .= 'BASE64';
          } else {
            $vCard .= 'b';
          }
          $vCard .= ';TYPE='.$Request['Logo_Format'].':'.trim($Request['Logo_Source_Quoted'])."\n";
          break;
        case 'QUOTED-PRINTABLE':
          $vCard .= 'ENCODING:QUOTED-PRINTABLE;TYPE='.$Request['Logo_Format'].':'.trim($Request['Logo_Source_Quoted'])."\n";
          break;
        case 'URL':
        default:
          $vCard .= 'VALUE=';
          if ($Request['Version-vCard'] == '2.1') {
            $vCard .= 'URL:';
          } else {
            $vCard .= 'uri:';
          }
          $vCard .= trim($Request['Logo_Source_URL'])."\n";
      }
    }

    // Agent
    if ($Request['Agent_Type'] != 'None') {
      $vCard .= 'AGENT';
      switch ($Request['Agent_Type']) {
        case 'URL':
          if ($Request['Version-vCard'] == '3.0') {
            $vCard .= ';VALUE=uri:'.trim($Request['Agent_URL'])."\n";
          }
          break;
        case 'vCard':
        default:
          $vCard .= ':'."\n".trim($Request['Agent'])."\n";
      }
    }

    // Organisation Name and Organisational Unit
    if (trim($Request['OrganisationalProperties_OrganisationName']) != '') {
      $vCard .= 'ORG:'.trim($Request['OrganisationalProperties_OrganisationName']);
      if (trim($Request['OrganisationalProperties_OrganisationalUnit']) != '') {
        $vCard .= ';'.trim($Request['OrganisationalProperties_OrganisationalUnit'])."\n";
      } else {
        $vCard .= "\n";
      }
    }

    // Categories (only 3.0)
    if ($Request['Version-vCard'] == '3.0' && $Request['Categories'] != '') {
      $vCard .= 'CATEGORIES:'.trim($Request['Categories'])."\n";
    }

    // Comment
    if (trim($Request['Comment_Quoted']) != '') {
      $vCard .= 'NOTE';
      if ($Request['Version-vCard'] == '2.1') {
        $vCard .= ';ENCODING=QUOTED-PRINTABLE';
      }
      $vCard .= ':'.trim($Request['Comment_Quoted'])."\n";
    }

    // Sound
    if ($Request['Sound_Type'] != 'None') {
      $vCard .= 'SOUND';
      switch ($Request['Sound_Type']) {
        case 'BASE64':
          $vCard .= ';';
          if ($Request['Version-vCard'] == '3.0') {
            $vCard .= 'TYPE=';
          }
          $vCard .= $Request['Sound_Format'];
          if ($Request['Version-vCard'] == '2.1') {
            $vCard .= ';BASE64:';
          } else {
            $vCard .= ';ENCODING=b:';
          }
          $vCard .= trim($Request['Sound_Source_Quoted'])."\n";
          break;
        case 'Phonetic':
          $vCard .= ':'.trim($Request['Sound_Source_Phonetic'])."\n";
          break;
        case 'URL':
        default:
          $vCard .= ';VALUE=';
          if ($Request['Version-vCard'] == '2.1') {
            $vCard .= 'URL:';
          } else {
            $vCard .= 'uri:';
          }
          $vCard .= trim($Request['Sound_Source_URL'])."\n";
      }
    }

    // URL
    if (trim($Request['URL'] != '')) {
      $vCard .= 'URL:'.trim($Request['URL'])."\n";
    }

    // Class (only 3.0)
    if ($Request['Version-vCard'] == '3.0' && $Request['Class'] != '') {
      $vCard .= 'CLASS:'.trim($Request['Class'])."\n";
    }

    // Key
    if ($Request['Key_Type'] != 'None') {
      $vCard .= 'KEY;';
      switch ($Request['Key_Type']) {
        case 'B':
          $vCard .= 'ENCODING=b:'.trim($Request['Key_Quoted'])."\n";
          break;
        case 'X509':
          $vCard .= 'X509:'.trim($Request['Key_Quoted'])."\n";
          break;
        case 'PGP':
        default:
          $vCard .= 'PGP:'.trim($Request['Key_Quoted'])."\n";
      }
    }

    // Unique Identifier
    $vCard .= 'UID:'.md5(uniqid(rand(), true))."\n";

    // Last Revision Date
    date_default_timezone_set('Europe/London');
    $vCard .= 'REV:'.date('Y-m-d\TH\\\:i\\\:s\Z')."\n";

    // Add generator field (non-standard)
    $vCard .= 'X-GENERATOR:'.vCardMaker::Version(true).' (http://vcardmaker.wackomenace.co.uk/)'."\n";
    if ($Request['Version-vCard'] == '3.0') {
      $vCard .= 'PRODID:-//OOGYNETWORKS//NONSGML VCARDMAKER '.vCardMaker::Version(false).'//EN'."\n";
    }

    // End vCard Delimiter
    $vCard .= 'END:VCARD';

    // Send the vCard
    if ($Return == 0) {
      return $vCard;
    } else if ($Return == 1) {
      echo '<pre id="result"><strong>'.$vCardLang['RvCardHeader'].'</strong>'."\n\n".$vCard."\n\n".'<strong>'.$vCardLang['RvCardFooter'].'</pre>';
    } else {
      echo $vCard;
    }

  }

}

?>