<?php

/**
 * vCardMaker
 *
 * Creates an electronic business card based on the vCard standard from provided information.
 *
 * Copyright (C) 2005-2008 oogyNetworks. All rights reserved.
 *
 * @author Ruben Arakelyan
 */

$vCardLang = array();

// Creator strings
$vCardLang['CToggleAdvanced']      = 'Advanced options';
$vCardLang['CInstructions1']       = 'This wizard will guide you through creating your electronic business card.<br />Let\'s get started. Tell us your name and a couple more details, then click Next.';
$vCardLang['CInstructions2']       = 'Tell us more about where you live...';
$vCardLang['CInstructions3']       = 'Tell us how to contact you...';
$vCardLang['CInstructions4']       = 'Tell us more about where you work...';
$vCardLang['CInstructions5']       = 'Tell us a few more miscellaneous things...';
$vCardLang['CInstructions6']       = 'Here\'s your vCard';
$vCardLang['CVersion']             = 'vCard Version';
$vCardLang['CVersion21']           = '2.1';
$vCardLang['CVersion30']           = '3.0';
$vCardLang['CName']                = 'vCard Name';
$vCardLang['CSource']              = 'vCard Source URL';
$vCardLang['CFormattedName']       = 'Full Name';
$vCardLang['CFormattedNameCap']    = 'This will be filled in automatically.';
$vCardLang['CPrefix']              = 'Title';
$vCardLang['CForename']            = 'Forename';
$vCardLang['CMiddleNames']         = 'Middle Name(s)';
$vCardLang['CSurname']             = 'Surname';
$vCardLang['CSuffix']              = 'Suffix';
$vCardLang['CSort']                = 'Sort Order';
$vCardLang['CNickname']            = 'Nickname(s)';
$vCardLang['CPhotoType']           = 'Photo';
$vCardLang['CPhotoTypeNone']       = 'None';
$vCardLang['CPhotoTypeURL']        = 'URL';
$vCardLang['CPhotoTypeBase64']     = 'Base64 (Binary)';
$vCardLang['CPhotoTypeQP']         = 'Quoted-Printable';
$vCardLang['CPhotoURL']            = 'Photo URL';
$vCardLang['CPhotoFormat']         = 'Photo Format';
$vCardLang['CPhoto']               = 'Photo Source';
$vCardLang['CBirthdate']           = 'Birth Date';
$vCardLang['CBirthtime']           = 'Birth Time';
$vCardLang['CBirthtimezone']       = 'Birth Timezone';
$vCardLang['CDeliveryAddressDom']  = 'Domestic';
$vCardLang['CDeliveryAddressInt']  = 'International';
$vCardLang['CDeliveryAddressPos']  = 'Postal';
$vCardLang['CDeliveryAddressPar']  = 'Parcel';
$vCardLang['CDeliveryAddressHome'] = 'Home';
$vCardLang['CDeliveryAddressWork'] = 'Work';
$vCardLang['CDeliveryAddressPOAd'] = 'Post Office Address';
$vCardLang['CDeliveryAddressExtA'] = 'Building Name';
$vCardLang['CDeliveryAddressStr']  = 'Street';
$vCardLang['CDeliveryAddressLoc']  = 'Locality';
$vCardLang['CDeliveryAddressReg']  = 'Region';
$vCardLang['CDeliveryAddressPC']   = 'Postal Code';
$vCardLang['CDeliveryAddressCoun'] = 'Country';
$vCardLang['CDeliveryLabelDom']    = 'Domestic';
$vCardLang['CDeliveryLabelInt']    = 'International';
$vCardLang['CDeliveryLabelPos']    = 'Postal';
$vCardLang['CDeliveryLabelPar']    = 'Parcel';
$vCardLang['CDeliveryLabelHome']   = 'Home';
$vCardLang['CDeliveryLabelWork']   = 'Work';
$vCardLang['CDeliveryLabelPOAd']   = 'Post Office Address';
$vCardLang['CDeliveryLabelExtA']   = 'Building Name';
$vCardLang['CDeliveryLabelStr']    = 'Street';
$vCardLang['CDeliveryLabelLoc']    = 'Locality';
$vCardLang['CDeliveryLabelReg']    = 'Region';
$vCardLang['CDeliveryLabelPC']     = 'Postal Code';
$vCardLang['CDeliveryLabelCoun']   = 'Country';
$vCardLang['CTelNumType']          = 'Telephone Number Type';
$vCardLang['CTelNumTelNum']        = 'Telephone Number';
$vCardLang['CTelNumPref']          = 'Preferred telephone number';
$vCardLang['CTelNumMsg']           = 'There is a messaging service on this number';
$vCardLang['CTelNumWork']          = 'Work';
$vCardLang['CTelNumHome']          = 'Home';
$vCardLang['CTelNumVoice']         = 'Voice';
$vCardLang['CTelNumFax']           = 'Fax';
$vCardLang['CTelNumCell']          = 'Mobile';
$vCardLang['CTelNumPager']         = 'Pager';
$vCardLang['CTelNumBBS']           = 'Bulletin Board Service';
$vCardLang['CTelNumModem']         = 'Modem';
$vCardLang['CTelNumCarphone']      = 'Car Phone';
$vCardLang['CTelNumISDN']          = 'ISDN';
$vCardLang['CTelNumVideophone']    = 'Video Phone';
$vCardLang['CEmailType']           = 'Email Address Type';
$vCardLang['CEmailPref']           = 'Preferred email address';
$vCardLang['CEmailAddress']        = 'Email Address';
$vCardLang['CMailer']              = 'Email Application Name';
$vCardLang['CGeoTimezone']         = 'Timezone';
$vCardLang['CGeoPos']              = 'Address Position<br />(latitude, longitude)';
$vCardLang['COrgTitle']            = 'Job Title';
$vCardLang['COrgRole']             = 'Job Role';
$vCardLang['CLogoType']            = 'Organisation Logo';
$vCardLang['CLogoTypeNone']        = 'None';
$vCardLang['CLogoTypeURL']         = 'URL';
$vCardLang['CLogoTypeBase64']      = 'Base64 (Binary)';
$vCardLang['CLogoTypeQP']          = 'Quoted-Printable';
$vCardLang['CLogoURL']             = 'Logo URL';
$vCardLang['CLogoFormat']          = 'Logo Format';
$vCardLang['CLogo']                = 'Logo Source';
$vCardLang['CAgentType']           = 'Agent (alternate contact)';
$vCardLang['CAgentTypeNone']       = 'None';
$vCardLang['CAgentTypevCard']      = 'vCard';
$vCardLang['CAgentTypeURL']        = 'URL';
$vCardLang['CAgentvCard']          = 'Agent vCard';
$vCardLang['CAgentURL']            = 'Agent URL';
$vCardLang['COrgName']             = 'Organisation Name';
$vCardLang['COrgUnit']             = 'Organisational Unit';
$vCardLang['CCategories']          = 'Categories';
$vCardLang['CComment']             = 'Comments';
$vCardLang['CSoundType']           = 'Sound';
$vCardLang['CSoundTypeNone']       = 'None';
$vCardLang['CSoundTypePhonetic']   = 'Phonetic';
$vCardLang['CSoundTypeURL']        = 'URL';
$vCardLang['CSoundTypeBase64']     = 'Base64 (Binary)';
$vCardLang['CSoundPhonetic']       = 'Phonetic Representation';
$vCardLang['CSoundURL']            = 'Sound URL';
$vCardLang['CSoundFormat']         = 'Sound Format';
$vCardLang['CSound']               = 'Sound Source';
$vCardLang['CURL']                 = 'URL';
$vCardLang['CClass']               = 'Class';
$vCardLang['CKeyType']             = 'Encryption Key';
$vCardLang['CKeyTypeNone']         = 'None';
$vCardLang['CKeyTypePGP']          = 'PGP';
$vCardLang['CKeyTypeX509']         = 'X.509';
$vCardLang['CKeyTypeBinary']       = 'Binary';
$vCardLang['CKey']                 = 'Key Source';
$vCardLang['CvCardPreviousButton'] = '&#171; Previous';
$vCardLang['CvCardNextButton']     = 'Next &#187;';
$vCardLang['CvCardSubmitButton']   = 'Get vCard';

// Result strings
$vCardLang['RvCardHeader']         = 'Here is your vCard:';
$vCardLang['RvCardFooter']         = 'If you asked us to email your vCard to you, you\'ll receive it shortly.';

// Email strings
$vCardLang['ESubject']             = 'Your vCard from vCardMaker';
$vCardLang['EMessage']             = "Hello!\n\nYou recently created a vCard using the vCardMaker at http://www.vcardmaker.co.uk/ and told us to email it to you. Your vCard is included below between the dashes. If you didn't request this message, please email us at vcardmaker@oogynetworks.com, including this email in your reply, and we'll make sure it doesn't happen again.\n\nThanks for using the vCardMaker!";

?>