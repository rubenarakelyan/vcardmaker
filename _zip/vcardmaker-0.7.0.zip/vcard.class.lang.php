<?php

/**
 * vCardMaker
 *
 * Creates an electronic business card based on the vCard standard from provided information.
 *
 * Copyright (C) 2005-2008 oogyNetworks. All rights reserved.
 *
 * @author Ruben Arakelyan
 */

$vCardLang = array();

// Validator strings
$vCardLang['NoVersion']            = 'The vCard version is blank.';
$vCardLang['NoFormattedName']      = 'The full name is blank.';
$vCardLang['NoForename']           = 'The forename is blank.';
$vCardLang['NoSurname']            = 'The surname is blank.';
$vCardLang['NoNameSource']         = 'If name or source are used, then both must be provided.';
$vCardLang['NoBirthdate']          = 'The birth date is not in the correct format.';
$vCardLang['NoBirthdatetime']      = 'If the birth time is provided then the birth date must be provided.';
$vCardLang['NoBirthtime']          = 'The birth time is not in the correct format.';
$vCardLang['NoBirthtimezone']      = 'If the birth timezone is provided then the birth time must be provided.';
$vCardLang['NoSoundPhonetic']      = 'The phonetic type for a sound cannot be used in a 3.0 vCard.';
$vCardLang['NoSoundPhoneticR']     = 'The phonetic representation for your sound is blank.';
$vCardLang['NoSoundURL']           = 'The URL for your sound is blank.';
$vCardLang['NoSoundSource']        = 'The sound source is blank.';
$vCardLang['NoPhotoURL']           = 'The photo URL is blank.';
$vCardLang['NoPhotoSource']        = 'The photo source is blank.';
$vCardLang['NoPhotoQP']            = 'The Quoted-Printable type for a photo cannot be used in a 3.0 vCard.';
$vCardLang['NoDeliveryStreet']     = 'The street name for your address is blank.';
$vCardLang['NoDeliveryLocality']   = 'The locality for your address is blank.';
$vCardLang['NoDeliveryPostCode']   = 'The postal code for your address is blank.';
$vCardLang['NoDeliveryCountry']    = 'The country for your address is blank.';
$vCardLang['NoLabelStreet']        = 'The street name for your delivery label is blank.';
$vCardLang['NoLabelLocality']      = 'The locality for your delivery label is blank.';
$vCardLang['NoLabelPostCode']      = 'The postal code for your delivery label is blank.';
$vCardLang['NoLabelCountry']       = 'The country for your delivery label is blank.';
$vCardLang['NoTelNumber']          = 'The telephone number is blank.';
$vCardLang['NoEmailAddress']       = 'The email address is blank.';
$vCardLang['NoGeoLoc']             = 'The geographical location is incorrect.';
$vCardLang['NoLogoURL']            = 'The URL for your logo is blank.';
$vCardLang['NoLogoSource']         = 'The logo source is blank.';
$vCardLang['NoLogoQP']             = 'The Quoted-Printable type for a logo cannot be used in a 3.0 vCard.';
$vCardLang['NoAgentvCard']         = 'The vCard for your agent is blank.';
$vCardLang['NoAgentURL']           = 'The URL for your agent is blank.';
$vCardLang['NoAgentURLType']       = 'The URL agent type cannot be used in a 2.1 vCard.';
$vCardLang['NoKeyBinary']          = 'The binary key type cannot be used in a 2.1 vCard.';
$vCardLang['NoKeyPGPX509']         = 'The PGP and X.509 key types cannot be used in a 3.0 vCard.';
$vCardLang['NoKeySource']          = 'The key is blank.';
$vCardLang['VErrorsFound']         = 'The following errors were found:';

?>