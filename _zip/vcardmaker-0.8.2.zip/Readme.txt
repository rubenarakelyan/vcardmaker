vCardMaker 0.8.2 (Play Me)
--------------------------

Thanks for downloading vCardMaker. Both the PHP and C# versions are included in this package. The C# version can be used both with Windows/IIS and Linux running Mono.

Keep in mind that these scripts are only the backend. You should design and build an appropriate frontend wrapper in the language of your choice to collect data and pass it to the script for processing.

The PHP version consists of two files: vCardMaker.php (the backend) and vCardMaker_Lang.php (error strings which can be customised). The C# version includes both parts in one file: vCardMaker.cs. As well as customising any strings, remember to include a valid email address at the bottom of your chosen script where denoted. This email address will appear as the "from" address in any emails sent by the backend script.

Have fun!